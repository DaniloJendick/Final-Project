function a(a){
    return a.replace(/s/gi, "5")
    .replace(/e/gi, "3")
    .replace(/i/gi, "1")
    .replace(/o/gi, "0")
    .replace(/a/gi, "4")

}
console.log(a("sou hasckesr"))