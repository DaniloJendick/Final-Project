import AccountCreation from "../../components/AccountCreation";

export default function SignUpPage() {
    return (
        <div>
            <AccountCreation />
        </div>
    )
}