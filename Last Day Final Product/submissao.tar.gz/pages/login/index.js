import SignIn from "../../components/SignIn";


export default function login() {
    return (
        <SignIn />
    )
}