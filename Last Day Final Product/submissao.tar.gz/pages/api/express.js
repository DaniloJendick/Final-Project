App.get("/carrinho", (req, res) => {

})
