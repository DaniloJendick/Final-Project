export default (req, res) => {
    if (req.method === "GET") {
    }
}