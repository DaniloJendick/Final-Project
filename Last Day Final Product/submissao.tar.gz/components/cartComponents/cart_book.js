export default function cartBook(props) {
    const { name, year, state, price, author, publisher } = props.book;
    return (
        <div>
            <div><img src="#" /></div>
            <div></div>
        </div>
    )
}