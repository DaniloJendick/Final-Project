import Link from "next/link"

export default function BurgerMenu(){
    return(
        <div>
            <Link href="/"></Link>
            <Link href=""></Link>
            <Link href=""></Link>
            <Link href=""></Link>
            <Link href=""></Link>
        </div>
    )
}